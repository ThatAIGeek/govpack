This package was created to ease and speed up access to the public data published by the Government of Ukraine on the https://data.gov.ua/ website ...

First dataset (meds_set1). Official data name: "Інформація про погашені електронні рецепти за програмою реімбурсації лікарських засобів («Доступні ліки»)", time period: 2018-2020 years, source link: https://data.gov.ua/dataset/5334586c-5bd1-4e24-9c14-9ba826cc9fa1

Second dataset (meds_set2). Official data name: "Оплати аптечним закладам за договорами реімбурсації лікарських засобів («Доступні ліки») з НСЗУ", time period: 2019-2020 years, source link: https://data.gov.ua/dataset/959dca0a-9b74-41ff-a7c8-f8de6398a219

Third dataset (meds_set1). Official data name: "Оплати надавачам медичної допомоги за програмою медичних гарантій", time period: 2019-2020 years, source link: https://data.gov.ua/dataset/25a46db9-2f15-4302-9b59-9bd761c80f46
